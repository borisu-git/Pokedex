//
// Created by nathan letourneau on 29/05/2022.
//

#include "all.h"

void init_prog(){
    actions();
}

void actions() {
    int whatAction = 0;
    int (*actionsTab[2])(struct Pokemon* pokemon) = {&create, &display}; // ca permet de créer ton tableau de pointeur sur donction
    Pokemon* pokemon = malloc(sizeof(Pokemon)); // la j'initialise la tête de la liste chainé
    Pokemon* head = pokemon; // et ici je la sauvegarde car pokemon juste au dessus va être modifier tout le temps

    do {
        printf("Que voulez vous faire ? : "); // on demande a l'utilisateur ce qu'il veut faire
        scanf("%d", &whatAction);

        actionsTab[whatAction](pokemon); // 0 va call create et 1 display
        pokemon = head; // une foi le traitement terminé on remet pokemon en haut de la list

        fflush(stdin); // ca permet de remettre a 0 le buffer.

    } while (whatAction != 10);
    free(pokemon); // toujours free les mallocs
}


int create(struct Pokemon* pokemon){
    while(pokemon->nextPokemon != NULL){ // permet de parcourir la la liste chainé jusqu'à la fin
        //TODO pour ajouter un pokemon qui a déjà été trouvé il faut faire un if comparer les nom et incrémenter un compteur dans la structure
        // ensuite arrêter le processus
        /*
         * if(...){
         *      pokemon->counter += 1
         *      return 1;
         * }
         * */
        pokemon = pokemon->nextPokemon;
    }

    /*
     * un début de traitement pour ajouter un pokemeon à là fin
    */
    pokemon->nextPokemon = malloc(sizeof(Pokemon));
    pokemon->nextPokemon->type = 1;
    strcpy(pokemon->nextPokemon->nom, "tiouant");
    return 1;
}

int display(struct Pokemon* pokemon){
    while(pokemon->nextPokemon != NULL){
        printf("%s\n", pokemon->nom);
        pokemon = pokemon->nextPokemon;
    }
    return 0;
}