#ifndef ALL_H
#define ALL_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>


#include "pokedex.h"

#endif
