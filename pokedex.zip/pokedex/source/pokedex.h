//
// Created by nathan letourneau on 29/05/2022.
//

#ifndef POKEDEX_POKEDEX_H
#define POKEDEX_POKEDEX_H



typedef struct Pokemon{ // la structure des pokemons
    char nom[50];
    int type;
    int possede;
    struct Pokemon* nextPokemon;
}Pokemon;


void init_prog();
void actions();
int create(struct Pokemon* pokemon);
int display(struct Pokemon* pokemon);
#endif //POKEDEX_POKEDEX_H
