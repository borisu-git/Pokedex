#include "source/all.h"
#include<unistd.h>

int main(int argc, char const *argv[]) {
    char *command = malloc(strlen(argv[0]) + 1);
    strcpy(command, argv[0]);
    char *a = strrchr(command, '/');
    a[1] = 0;
    chdir(command);

    init_prog();
    return EXIT_SUCCESS;
}
